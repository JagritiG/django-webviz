from django.apps import AppConfig


class VizConfig(AppConfig):
    name = 'viz'
